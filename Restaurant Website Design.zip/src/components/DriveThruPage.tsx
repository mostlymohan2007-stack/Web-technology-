import { ImageWithFallback } from './figma/ImageWithFallback';
import { Car, Clock, CreditCard, CheckCircle, MapPin, Phone } from 'lucide-react';

export function DriveThruPage() {
  const steps = [
    {
      icon: Phone,
      title: 'Order Ahead',
      description: 'Call us or order online to skip the wait. Your food will be ready when you arrive.',
    },
    {
      icon: Car,
      title: 'Drive to Our Location',
      description: 'Navigate to our drive-thru lane. Follow the signs and pull up to the ordering window.',
    },
    {
      icon: CreditCard,
      title: 'Pay & Confirm',
      description: 'Present your order confirmation or place a new order. We accept all major payment methods.',
    },
    {
      icon: CheckCircle,
      title: 'Collect Your Order',
      description: 'Pull forward to the pickup window. Check your order and enjoy your meal!',
    },
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="relative h-[500px] overflow-hidden">
        <ImageWithFallback
          src="https://images.unsplash.com/photo-1700978804711-10b64e63a071?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyZXN0YXVyYW50JTIwZXh0ZXJpb3IlMjBtb2Rlcm58ZW58MXx8fHwxNzY0NTc1Mjg0fDA&ixlib=rb-4.1.0&q=80&w=1080"
          alt="Drive-thru exterior"
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/60 to-black/30" />
        
        <div className="relative h-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center">
          <div className="max-w-2xl text-white">
            <h1 className="mb-6">Drive-Thru Service</h1>
            <p className="text-xl text-stone-200">
              Get your favorite meals on the go. Quick, convenient, and delicious.
            </p>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <p className="text-amber-600 mb-2">Quick & Easy</p>
            <h2 className="mb-4">How Our Drive-Thru Works</h2>
            <p className="text-stone-600 max-w-2xl mx-auto">
              Four simple steps to enjoy your meal without leaving your car
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {steps.map((step, index) => (
              <div key={index} className="text-center">
                <div className="relative mb-6">
                  <div className="w-20 h-20 bg-gradient-to-br from-amber-500 to-orange-600 rounded-full flex items-center justify-center mx-auto">
                    <step.icon className="w-10 h-10 text-white" />
                  </div>
                  <div className="absolute -top-2 -right-2 w-10 h-10 bg-amber-100 rounded-full flex items-center justify-center mx-auto">
                    <span className="text-amber-600">{index + 1}</span>
                  </div>
                </div>
                <h5 className="text-stone-800 mb-3">{step.title}</h5>
                <p className="text-stone-600">{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Timing & Guidelines Section */}
      <section className="py-20 bg-amber-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Operating Hours */}
            <div className="bg-white rounded-2xl p-8 shadow-md">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 bg-amber-100 rounded-full flex items-center justify-center">
                  <Clock className="w-6 h-6 text-amber-600" />
                </div>
                <h4 className="text-stone-800">Drive-Thru Hours</h4>
              </div>
              <div className="space-y-4">
                <div className="flex justify-between items-center py-3 border-b border-stone-200">
                  <span className="text-stone-700">Monday - Thursday</span>
                  <span className="text-stone-900">10:00 AM - 10:00 PM</span>
                </div>
                <div className="flex justify-between items-center py-3 border-b border-stone-200">
                  <span className="text-stone-700">Friday - Saturday</span>
                  <span className="text-stone-900">10:00 AM - 11:00 PM</span>
                </div>
                <div className="flex justify-between items-center py-3">
                  <span className="text-stone-700">Sunday</span>
                  <span className="text-stone-900">10:00 AM - 9:00 PM</span>
                </div>
              </div>
            </div>

            {/* Location */}
            <div className="bg-white rounded-2xl p-8 shadow-md">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 bg-amber-100 rounded-full flex items-center justify-center">
                  <MapPin className="w-6 h-6 text-amber-600" />
                </div>
                <h4 className="text-stone-800">Our Location</h4>
              </div>
              <div className="space-y-4">
                <div>
                  <p className="text-stone-600 mb-2">Address</p>
                  <p className="text-stone-900">
                    123 Culinary Street<br />
                    Food District, NY 10001
                  </p>
                </div>
                <div>
                  <p className="text-stone-600 mb-2">Contact</p>
                  <p className="text-stone-900">(555) 123-4567</p>
                </div>
                <button className="mt-4 bg-amber-600 hover:bg-amber-700 text-white px-6 py-3 rounded-full transition-colors">
                  Get Directions
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Guidelines Section */}
      <section className="py-20 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h3 className="mb-4">Pickup Guidelines</h3>
            <p className="text-stone-600">
              Please follow these simple guidelines to ensure a smooth experience
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-amber-50 rounded-xl p-6">
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-amber-600 flex items-center justify-center flex-shrink-0 mt-1">
                  <CheckCircle className="w-4 h-4 text-white" />
                </div>
                <div>
                  <h6 className="text-stone-800 mb-2">Have Your Order Ready</h6>
                  <p className="text-stone-600 text-sm">
                    Keep your order number or confirmation handy for quick verification
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-amber-50 rounded-xl p-6">
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-amber-600 flex items-center justify-center flex-shrink-0 mt-1">
                  <CheckCircle className="w-4 h-4 text-white" />
                </div>
                <div>
                  <h6 className="text-stone-800 mb-2">Payment Methods</h6>
                  <p className="text-stone-600 text-sm">
                    We accept cash, credit cards, and contactless payments
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-amber-50 rounded-xl p-6">
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-amber-600 flex items-center justify-center flex-shrink-0 mt-1">
                  <CheckCircle className="w-4 h-4 text-white" />
                </div>
                <div>
                  <h6 className="text-stone-800 mb-2">Check Your Order</h6>
                  <p className="text-stone-600 text-sm">
                    Please verify your order before leaving the pickup window
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-amber-50 rounded-xl p-6">
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-amber-600 flex items-center justify-center flex-shrink-0 mt-1">
                  <CheckCircle className="w-4 h-4 text-white" />
                </div>
                <div>
                  <h6 className="text-stone-800 mb-2">Special Requests</h6>
                  <p className="text-stone-600 text-sm">
                    Mention any dietary requirements or customizations when ordering
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-amber-600 to-orange-600 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h3 className="mb-4 text-white">Ready to Order?</h3>
          <p className="text-xl text-amber-50 mb-8">
            Call ahead or use our online ordering system for the fastest service
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="bg-white text-amber-600 hover:bg-amber-50 px-8 py-3 rounded-full transition-colors">
              Order Online
            </button>
            <button className="border-2 border-white text-white hover:bg-white/10 px-8 py-3 rounded-full transition-colors">
              Call (555) 123-4567
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}
