import { MapPin, Phone, Mail, Clock, Send, ChevronDown, ChevronUp } from 'lucide-react';
import { useState } from 'react';

export function ContactPage() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    message: '',
  });

  const [expandedFaq, setExpandedFaq] = useState<number | null>(null);

  const faqs = [
    {
      question: 'Do you take reservations?',
      answer: 'Yes! We highly recommend making a reservation, especially for dinner service and weekends. You can call us at (555) 123-4567 or book online through our website.',
    },
    {
      question: 'Do you accommodate dietary restrictions?',
      answer: 'Absolutely. We offer vegetarian, vegan, and gluten-free options. Please inform your server of any allergies or dietary requirements, and our chef will be happy to accommodate.',
    },
    {
      question: 'Is there parking available?',
      answer: 'Yes, we have a complimentary parking lot adjacent to the restaurant with spaces for over 50 vehicles. Street parking is also available nearby.',
    },
    {
      question: 'Do you offer catering services?',
      answer: 'Yes, we provide full-service catering for events of all sizes. Contact us for a customized menu and pricing.',
    },
    {
      question: 'Can I host a private event at your restaurant?',
      answer: 'We have a private dining room that can accommodate up to 40 guests. Perfect for birthdays, anniversaries, corporate events, and special celebrations.',
    },
    {
      question: 'Do you offer gift cards?',
      answer: 'Yes! Gift cards are available for purchase in any denomination at our restaurant or online. They make the perfect gift for food lovers.',
    },
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission
    alert('Thank you for your message! We will get back to you soon.');
    setFormData({ name: '', email: '', phone: '', message: '' });
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="bg-gradient-to-r from-amber-600 to-orange-600 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-white mb-4">Get In Touch</h1>
          <p className="text-xl text-amber-100">
            We'd love to hear from you. Reach out with any questions or feedback.
          </p>
        </div>
      </div>

      {/* Contact Info Cards */}
      <section className="py-20 bg-amber-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="bg-white rounded-2xl p-6 shadow-md text-center">
              <div className="w-14 h-14 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <MapPin className="w-7 h-7 text-amber-600" />
              </div>
              <h6 className="text-stone-800 mb-2">Address</h6>
              <p className="text-stone-600 text-sm">
                123 Culinary Street<br />
                Food District, NY 10001
              </p>
            </div>

            <div className="bg-white rounded-2xl p-6 shadow-md text-center">
              <div className="w-14 h-14 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Phone className="w-7 h-7 text-amber-600" />
              </div>
              <h6 className="text-stone-800 mb-2">Phone</h6>
              <p className="text-stone-600 text-sm">
                (555) 123-4567<br />
                (555) 123-4568
              </p>
            </div>

            <div className="bg-white rounded-2xl p-6 shadow-md text-center">
              <div className="w-14 h-14 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Mail className="w-7 h-7 text-amber-600" />
              </div>
              <h6 className="text-stone-800 mb-2">Email</h6>
              <p className="text-stone-600 text-sm">
                hello@savoria.com<br />
                reservations@savoria.com
              </p>
            </div>

            <div className="bg-white rounded-2xl p-6 shadow-md text-center">
              <div className="w-14 h-14 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Clock className="w-7 h-7 text-amber-600" />
              </div>
              <h6 className="text-stone-800 mb-2">Hours</h6>
              <p className="text-stone-600 text-sm">
                Mon-Thu: 11 AM - 10 PM<br />
                Fri-Sat: 11 AM - 11 PM
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Form & Map Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
            {/* Contact Form */}
            <div>
              <h3 className="mb-6">Send Us a Message</h3>
              <p className="text-stone-600 mb-8">
                Have a question or special request? Fill out the form below and we'll get back to you as soon as possible.
              </p>

              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label htmlFor="name" className="block text-stone-700 mb-2">
                    Full Name *
                  </label>
                  <input
                    type="text"
                    id="name"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full px-4 py-3 rounded-lg border border-stone-300 focus:outline-none focus:ring-2 focus:ring-amber-500"
                    placeholder="John Doe"
                  />
                </div>

                <div>
                  <label htmlFor="email" className="block text-stone-700 mb-2">
                    Email Address *
                  </label>
                  <input
                    type="email"
                    id="email"
                    required
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full px-4 py-3 rounded-lg border border-stone-300 focus:outline-none focus:ring-2 focus:ring-amber-500"
                    placeholder="john@example.com"
                  />
                </div>

                <div>
                  <label htmlFor="phone" className="block text-stone-700 mb-2">
                    Phone Number
                  </label>
                  <input
                    type="tel"
                    id="phone"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full px-4 py-3 rounded-lg border border-stone-300 focus:outline-none focus:ring-2 focus:ring-amber-500"
                    placeholder="(555) 123-4567"
                  />
                </div>

                <div>
                  <label htmlFor="message" className="block text-stone-700 mb-2">
                    Message *
                  </label>
                  <textarea
                    id="message"
                    required
                    rows={6}
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    className="w-full px-4 py-3 rounded-lg border border-stone-300 focus:outline-none focus:ring-2 focus:ring-amber-500 resize-none"
                    placeholder="Tell us what you'd like to know..."
                  />
                </div>

                <button
                  type="submit"
                  className="w-full bg-amber-600 hover:bg-amber-700 text-white py-3 rounded-full transition-colors flex items-center justify-center gap-2"
                >
                  <Send className="w-5 h-5" />
                  Send Message
                </button>
              </form>
            </div>

            {/* Map Section */}
            <div>
              <h3 className="mb-6">Find Us</h3>
              <div className="bg-stone-200 rounded-2xl h-96 flex items-center justify-center mb-6">
                <div className="text-center text-stone-500">
                  <MapPin className="w-16 h-16 mx-auto mb-4" />
                  <p>Interactive map would be displayed here</p>
                  <p className="text-sm mt-2">123 Culinary Street, Food District, NY 10001</p>
                </div>
              </div>

              <div className="bg-amber-50 rounded-2xl p-6">
                <h5 className="text-stone-800 mb-4">Getting Here</h5>
                <div className="space-y-3 text-sm text-stone-700">
                  <p>
                    <strong>By Car:</strong> Take Exit 12 off Highway 95, then follow signs to Food District. Free parking available.
                  </p>
                  <p>
                    <strong>By Public Transit:</strong> Take the Blue Line to Culinary Station (5-minute walk).
                  </p>
                  <p>
                    <strong>By Rideshare:</strong> We're easily accessible via Uber and Lyft. Drop-off zone at main entrance.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 bg-amber-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="mb-4">Frequently Asked Questions</h2>
            <p className="text-stone-600">
              Quick answers to common questions about Savoria
            </p>
          </div>

          <div className="space-y-4">
            {faqs.map((faq, index) => (
              <div key={index} className="bg-white rounded-xl shadow-md overflow-hidden">
                <button
                  onClick={() => setExpandedFaq(expandedFaq === index ? null : index)}
                  className="w-full px-6 py-5 flex items-center justify-between text-left hover:bg-stone-50 transition-colors"
                >
                  <h6 className="text-stone-800 pr-4">{faq.question}</h6>
                  {expandedFaq === index ? (
                    <ChevronUp className="w-5 h-5 text-amber-600 flex-shrink-0" />
                  ) : (
                    <ChevronDown className="w-5 h-5 text-amber-600 flex-shrink-0" />
                  )}
                </button>
                {expandedFaq === index && (
                  <div className="px-6 pb-5">
                    <p className="text-stone-600">{faq.answer}</p>
                  </div>
                )}
              </div>
            ))}
          </div>

          <div className="mt-12 text-center">
            <p className="text-stone-600 mb-4">
              Still have questions? We're here to help!
            </p>
            <button className="border-2 border-amber-600 text-amber-600 hover:bg-amber-600 hover:text-white px-8 py-3 rounded-full transition-colors">
              Call Us: (555) 123-4567
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}
