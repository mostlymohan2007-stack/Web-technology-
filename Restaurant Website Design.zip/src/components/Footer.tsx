import { MapPin, Phone, Mail, Clock, Facebook, Instagram, Twitter } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-stone-900 text-stone-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          {/* About */}
          <div>
            <h5 className="text-white mb-4">Savoria</h5>
            <p className="text-sm mb-6">
              Experience the finest culinary journey with our expertly crafted dishes and warm hospitality.
            </p>
            <div className="flex gap-4">
              <button className="w-10 h-10 rounded-full bg-stone-800 hover:bg-amber-600 transition-colors flex items-center justify-center">
                <Facebook className="w-5 h-5" />
              </button>
              <button className="w-10 h-10 rounded-full bg-stone-800 hover:bg-amber-600 transition-colors flex items-center justify-center">
                <Instagram className="w-5 h-5" />
              </button>
              <button className="w-10 h-10 rounded-full bg-stone-800 hover:bg-amber-600 transition-colors flex items-center justify-center">
                <Twitter className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h6 className="text-white mb-4">Quick Links</h6>
            <ul className="space-y-3 text-sm">
              <li><a href="#" className="hover:text-amber-500 transition-colors">Menu</a></li>
              <li><a href="#" className="hover:text-amber-500 transition-colors">Reservations</a></li>
              <li><a href="#" className="hover:text-amber-500 transition-colors">Catering</a></li>
              <li><a href="#" className="hover:text-amber-500 transition-colors">Gift Cards</a></li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h6 className="text-white mb-4">Contact</h6>
            <ul className="space-y-3 text-sm">
              <li className="flex items-start gap-2">
                <MapPin className="w-4 h-4 mt-1 flex-shrink-0" />
                <span>123 Culinary Street, Food District, NY 10001</span>
              </li>
              <li className="flex items-center gap-2">
                <Phone className="w-4 h-4 flex-shrink-0" />
                <span>(555) 123-4567</span>
              </li>
              <li className="flex items-center gap-2">
                <Mail className="w-4 h-4 flex-shrink-0" />
                <span>hello@savoria.com</span>
              </li>
            </ul>
          </div>

          {/* Hours */}
          <div>
            <h6 className="text-white mb-4">Opening Hours</h6>
            <ul className="space-y-3 text-sm">
              <li className="flex items-start gap-2">
                <Clock className="w-4 h-4 mt-1 flex-shrink-0" />
                <div>
                  <p>Mon - Thu: 11:00 AM - 10:00 PM</p>
                  <p>Fri - Sat: 11:00 AM - 11:00 PM</p>
                  <p>Sunday: 10:00 AM - 9:00 PM</p>
                </div>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-stone-800 mt-12 pt-8 text-center text-sm">
          <p>&copy; 2024 Savoria Restaurant. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
