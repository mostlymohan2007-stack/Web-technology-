import { ImageWithFallback } from './figma/ImageWithFallback';
import { Heart, Award, Users, Leaf } from 'lucide-react';

export function AboutUsPage() {
  const values = [
    {
      icon: Heart,
      title: 'Passion for Food',
      description: 'Every dish is crafted with love and attention to detail, ensuring exceptional quality.',
    },
    {
      icon: Award,
      title: 'Excellence',
      description: 'We strive for perfection in every aspect, from ingredients to service.',
    },
    {
      icon: Users,
      title: 'Community',
      description: 'Building lasting relationships with our guests and supporting local producers.',
    },
    {
      icon: Leaf,
      title: 'Sustainability',
      description: 'Committed to eco-friendly practices and sourcing responsibly.',
    },
  ];

  const teamMembers = [
    {
      name: 'Chef Marcus Anderson',
      role: 'Executive Chef',
      image: 'https://images.unsplash.com/photo-1759521296047-89338c8e083d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaGVmJTIwcG9ydHJhaXQlMjBwcm9mZXNzaW9uYWx8ZW58MXx8fHwxNzY0NTM1OTA4fDA&ixlib=rb-4.1.0&q=80&w=1080',
      bio: '20+ years of culinary excellence across Michelin-starred restaurants worldwide.',
    },
    {
      name: 'Sofia Martinez',
      role: 'Pastry Chef',
      image: 'https://images.unsplash.com/photo-1759521296047-89338c8e083d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaGVmJTIwcG9ydHJhaXQlMjBwcm9mZXNzaW9uYWx8ZW58MXx8fHwxNzY0NTM1OTA4fDA&ixlib=rb-4.1.0&q=80&w=1080',
      bio: 'Award-winning pastry chef specializing in innovative dessert creations.',
    },
    {
      name: 'James Chen',
      role: 'Sous Chef',
      image: 'https://images.unsplash.com/photo-1759521296047-89338c8e083d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaGVmJTIwcG9ydHJhaXQlMjBwcm9mZXNzaW9uYWx8ZW58MXx8fHwxNzY0NTM1OTA4fDA&ixlib=rb-4.1.0&q=80&w=1080',
      bio: 'Passionate about farm-to-table cuisine and seasonal ingredients.',
    },
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-b from-amber-50 to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto">
            <p className="text-amber-600 mb-2">Welcome to Savoria</p>
            <h1 className="mb-6">Our Story</h1>
            <p className="text-xl text-stone-600">
              A passion for exceptional food, warm hospitality, and creating unforgettable dining experiences
            </p>
          </div>
        </div>
      </section>

      {/* Brand Story Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div className="relative h-[600px] rounded-2xl overflow-hidden">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1759419038843-29749ac4cd2d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyZXN0YXVyYW50JTIwaW50ZXJpb3IlMjBlbGVnYW50fGVufDF8fHx8MTc2NDQ3MTM5MXww&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Restaurant interior"
                className="w-full h-full object-cover"
              />
            </div>

            <div>
              <h2 className="mb-6">Where It All Began</h2>
              <div className="space-y-4 text-stone-700">
                <p>
                  Founded in 2008, Savoria was born from a simple dream: to create a place where food, family, and friends come together in perfect harmony. What started as a small neighborhood bistro has grown into a beloved culinary destination.
                </p>
                <p>
                  Our founder, Chef Marcus Anderson, traveled the world learning from master chefs before returning home with a vision. He wanted to create a restaurant that honored traditional techniques while embracing innovation and creativity.
                </p>
                <p>
                  Today, we continue that legacy by sourcing the finest local and seasonal ingredients, supporting our community, and treating every guest like family. Each dish tells a story, and every meal is a celebration.
                </p>
                <p>
                  From our wood-fired oven to our handcrafted desserts, everything at Savoria is made with passion, precision, and love. We're not just serving food—we're creating memories.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Mission & Values Section */}
      <section className="py-20 bg-amber-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="mb-4">Our Values</h2>
            <p className="text-stone-600 max-w-2xl mx-auto">
              The principles that guide everything we do
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => (
              <div key={index} className="bg-white rounded-2xl p-8 shadow-md text-center">
                <div className="w-16 h-16 bg-gradient-to-br from-amber-500 to-orange-600 rounded-full flex items-center justify-center mx-auto mb-4">
                  <value.icon className="w-8 h-8 text-white" />
                </div>
                <h5 className="text-stone-800 mb-3">{value.title}</h5>
                <p className="text-stone-600">{value.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Chef Introduction Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="mb-4">Meet Our Executive Chef</h2>
            <p className="text-stone-600 max-w-2xl mx-auto">
              The culinary visionary behind our exceptional menu
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center max-w-5xl mx-auto">
            <div className="relative h-[500px] rounded-2xl overflow-hidden order-2 lg:order-1">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1759521296047-89338c8e083d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaGVmJTIwcG9ydHJhaXQlMjBwcm9mZXNzaW9uYWx8ZW58MXx8fHwxNzY0NTM1OTA4fDA&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Chef Marcus Anderson"
                className="w-full h-full object-cover"
              />
            </div>

            <div className="order-1 lg:order-2">
              <h3 className="mb-4">Chef Marcus Anderson</h3>
              <p className="text-amber-600 mb-6">Executive Chef & Founder</p>
              <div className="space-y-4 text-stone-700">
                <p>
                  With over two decades of experience in the culinary world, Chef Marcus has trained under legendary chefs in Paris, Tokyo, and New York. His innovative approach to modern cuisine has earned him numerous accolades and a loyal following.
                </p>
                <p>
                  Marcus believes in letting quality ingredients speak for themselves. His philosophy is simple: source the best, treat it with respect, and let the natural flavors shine. This dedication to excellence is evident in every dish that leaves our kitchen.
                </p>
                <p>
                  When he's not in the kitchen, Marcus enjoys teaching cooking classes, exploring local farmers markets, and spending time with his family.
                </p>
              </div>

              <div className="mt-8 pt-8 border-t border-stone-200">
                <h6 className="text-stone-800 mb-4">Achievements</h6>
                <ul className="space-y-2 text-stone-700">
                  <li className="flex items-center gap-2">
                    <Award className="w-5 h-5 text-amber-600 flex-shrink-0" />
                    <span>James Beard Award Nominee (2019, 2021)</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <Award className="w-5 h-5 text-amber-600 flex-shrink-0" />
                    <span>Michelin Star - Le Jardin, Paris (2015)</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <Award className="w-5 h-5 text-amber-600 flex-shrink-0" />
                    <span>Featured in Food & Wine Magazine</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-20 bg-amber-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="mb-4">Our Culinary Team</h2>
            <p className="text-stone-600 max-w-2xl mx-auto">
              Talented chefs dedicated to creating exceptional experiences
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {teamMembers.map((member, index) => (
              <div key={index} className="bg-white rounded-2xl overflow-hidden shadow-md">
                <div className="relative h-80">
                  <ImageWithFallback
                    src={member.image}
                    alt={member.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="p-6">
                  <h5 className="text-stone-800 mb-1">{member.name}</h5>
                  <p className="text-amber-600 mb-3">{member.role}</p>
                  <p className="text-stone-600 text-sm">{member.bio}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Ambience Gallery Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="mb-4">Our Space</h2>
            <p className="text-stone-600 max-w-2xl mx-auto">
              An elegant atmosphere designed for comfort and celebration
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="relative h-96 rounded-2xl overflow-hidden">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1759419038843-29749ac4cd2d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyZXN0YXVyYW50JTIwaW50ZXJpb3IlMjBlbGVnYW50fGVufDF8fHx8MTc2NDQ3MTM5MXww&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Dining area"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="relative h-96 rounded-2xl overflow-hidden">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1700978804711-10b64e63a071?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyZXN0YXVyYW50JTIwZXh0ZXJpb3IlMjBtb2Rlcm58ZW58MXx8fHwxNzY0NTc1Mjg0fDA&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Restaurant exterior"
                className="w-full h-full object-cover"
              />
            </div>
          </div>

          <div className="mt-12 text-center">
            <p className="text-stone-700 max-w-3xl mx-auto">
              From intimate dinners to grand celebrations, our beautifully designed space provides the perfect backdrop for any occasion. With warm lighting, comfortable seating, and an inviting atmosphere, Savoria is where memories are made.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}
