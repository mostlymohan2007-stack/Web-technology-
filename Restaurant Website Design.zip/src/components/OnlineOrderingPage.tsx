import { useState } from 'react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { ShoppingCart, Plus, Minus, X, Search } from 'lucide-react';

interface CartItem {
  id: number;
  name: string;
  price: number;
  quantity: number;
  image: string;
}

export function OnlineOrderingPage() {
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [cart, setCart] = useState<CartItem[]>([]);
  const [cartOpen, setCartOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const categories = ['All', 'Starters', 'Mains', 'Desserts', 'Drinks'];

  const menuItems = [
    {
      id: 1,
      name: 'Vegetable Samosa',
      category: 'Starters',
      price: 6,
      description: 'Crispy pastry filled with spiced potatoes and peas',
      image: 'https://images.unsplash.com/photo-1697155836252-d7f969108b5a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzYW1vc2ElMjBpbmRpYW4lMjBzbmFja3xlbnwxfHx8fDE3NjQ1NzU2NTJ8MA&ixlib=rb-4.1.0&q=80&w=1080',
    },
    {
      id: 2,
      name: 'Tandoori Chicken',
      category: 'Starters',
      price: 12,
      description: 'Marinated chicken grilled in traditional clay oven',
      image: 'https://images.unsplash.com/photo-1595977233209-aadbe21490b6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0YW5kb29yaSUyMGNoaWNrZW4lMjB0aWtrYXxlbnwxfHx8fDE3NjQ1NzU2NTF8MA&ixlib=rb-4.1.0&q=80&w=1080',
    },
    {
      id: 3,
      name: 'Chicken Biryani',
      category: 'Mains',
      price: 18,
      description: 'Fragrant basmati rice layered with spiced chicken',
      image: 'https://images.unsplash.com/photo-1589302168068-964664d93dc0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmRpYW4lMjBiaXJ5YW5pJTIwcmljZXxlbnwxfHx8fDE3NjQ0ODAxMDF8MA&ixlib=rb-4.1.0&q=80&w=1080',
    },
    {
      id: 4,
      name: 'Butter Chicken',
      category: 'Mains',
      price: 16,
      description: 'Tender chicken in rich tomato-butter gravy',
      image: 'https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxidXR0ZXIlMjBjaGlja2VuJTIwY3Vycnl8ZW58MXx8fHwxNzY0NTY3ODgyfDA&ixlib=rb-4.1.0&q=80&w=1080',
    },
    {
      id: 5,
      name: 'Paneer Tikka Masala',
      category: 'Mains',
      price: 14,
      description: 'Grilled cottage cheese in creamy tomato sauce',
      image: 'https://images.unsplash.com/photo-1567188040759-fb8a883dc6d8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwYW5lZXIlMjB0aWtrYSUyMG1hc2FsYXxlbnwxfHx8fDE3NjQ1NzU2NTF8MA&ixlib=rb-4.1.0&q=80&w=1080',
    },
    {
      id: 6,
      name: 'Palak Paneer',
      category: 'Mains',
      price: 13,
      description: 'Cottage cheese in creamy spinach curry',
      image: 'https://images.unsplash.com/photo-1589647363585-f4a7d3877b10?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwYWxhayUyMHBhbmVlciUyMHNwaW5hY2h8ZW58MXx8fHwxNzY0NTc1NjUzfDA&ixlib=rb-4.1.0&q=80&w=1080',
    },
    {
      id: 7,
      name: 'Gulab Jamun',
      category: 'Desserts',
      price: 6,
      description: 'Soft milk dumplings in warm cardamom-rose syrup',
      image: 'https://images.unsplash.com/photo-1666190092159-3171cf0fbb12?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxndWxhYiUyMGphbXVuJTIwZGVzc2VydHxlbnwxfHx8fDE3NjQ0NzU5ODV8MA&ixlib=rb-4.1.0&q=80&w=1080',
    },
    {
      id: 8,
      name: 'Rasmalai',
      category: 'Desserts',
      price: 7,
      description: 'Soft cheese patties in sweet saffron milk',
      image: 'https://images.unsplash.com/photo-1666190092159-3171cf0fbb12?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxndWxhYiUyMGphbXVuJTIwZGVzc2VydHxlbnwxfHx8fDE3NjQ0NzU5ODV8MA&ixlib=rb-4.1.0&q=80&w=1080',
    },
    {
      id: 9,
      name: 'Mango Lassi',
      category: 'Drinks',
      price: 5,
      description: 'Sweet yogurt drink blended with fresh mango',
      image: 'https://images.unsplash.com/photo-1728777185717-a9d9bc2bd969?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYW5nbyUyMGxhc3NpJTIwZHJpbmt8ZW58MXx8fHwxNzY0NDc1OTg1fDA&ixlib=rb-4.1.0&q=80&w=1080',
    },
    {
      id: 10,
      name: 'Masala Chai',
      category: 'Drinks',
      price: 4,
      description: 'Spiced Indian tea with aromatic cardamom and ginger',
      image: 'https://images.unsplash.com/photo-1698619952010-3bc850cbcb3b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYXNhbGElMjBjaGFpJTIwdGVhfGVufDF8fHx8MTc2NDQ3ODU5MXww&ixlib=rb-4.1.0&q=80&w=1080',
    },
  ];

  const filteredItems = menuItems.filter((item) => {
    const matchesCategory = selectedCategory === 'All' || item.category === selectedCategory;
    const matchesSearch = item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const addToCart = (item: typeof menuItems[0]) => {
    const existingItem = cart.find((cartItem) => cartItem.id === item.id);
    if (existingItem) {
      setCart(
        cart.map((cartItem) =>
          cartItem.id === item.id
            ? { ...cartItem, quantity: cartItem.quantity + 1 }
            : cartItem
        )
      );
    } else {
      setCart([...cart, { ...item, quantity: 1 }]);
    }
    setCartOpen(true);
  };

  const updateQuantity = (id: number, change: number) => {
    setCart(
      cart
        .map((item) =>
          item.id === id ? { ...item, quantity: item.quantity + change } : item
        )
        .filter((item) => item.quantity > 0)
    );
  };

  const removeFromCart = (id: number) => {
    setCart(cart.filter((item) => item.id !== id));
  };

  const cartTotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const cartItemCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <div className="min-h-screen bg-stone-50">
      {/* Header */}
      <div className="bg-amber-600 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-white mb-4">Order Online</h1>
          <p className="text-xl text-amber-100">
            Browse our menu and enjoy delicious food delivered to your door
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Main Content */}
          <div className="flex-1">
            {/* Search */}
            <div className="mb-8">
              <div className="relative">
                <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-stone-400 w-5 h-5" />
                <input
                  type="text"
                  placeholder="Search menu items..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-12 pr-4 py-3 rounded-full border border-stone-300 focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>
            </div>

            {/* Category Filters */}
            <div className="flex flex-wrap gap-3 mb-8">
              {categories.map((category) => (
                <button
                  key={category}
                  onClick={() => setSelectedCategory(category)}
                  className={`px-6 py-2 rounded-full transition-colors ${
                    selectedCategory === category
                      ? 'bg-amber-600 text-white'
                      : 'bg-white text-stone-700 hover:bg-stone-100 border border-stone-300'
                  }`}
                >
                  {category}
                </button>
              ))}
            </div>

            {/* Menu Items Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {filteredItems.map((item) => (
                <div
                  key={item.id}
                  className="bg-white rounded-2xl overflow-hidden shadow-md hover:shadow-lg transition-shadow"
                >
                  <div className="flex">
                    <div className="w-40 h-40 flex-shrink-0">
                      <ImageWithFallback
                        src={item.image}
                        alt={item.name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="flex-1 p-6 flex flex-col">
                      <div className="flex-1">
                        <div className="flex justify-between items-start mb-2">
                          <h5 className="text-stone-800">{item.name}</h5>
                          <span className="text-amber-600">${item.price}</span>
                        </div>
                        <p className="text-sm text-stone-600 mb-4">{item.description}</p>
                      </div>
                      <button
                        onClick={() => addToCart(item)}
                        className="bg-amber-600 hover:bg-amber-700 text-white px-4 py-2 rounded-full text-sm transition-colors flex items-center justify-center gap-2"
                      >
                        <Plus className="w-4 h-4" />
                        Add to Cart
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Cart Button (Mobile) */}
          <button
            onClick={() => setCartOpen(true)}
            className="lg:hidden fixed bottom-6 right-6 bg-amber-600 text-white w-16 h-16 rounded-full shadow-lg flex items-center justify-center z-40"
          >
            <ShoppingCart className="w-6 h-6" />
            {cartItemCount > 0 && (
              <span className="absolute -top-2 -right-2 bg-red-500 text-white w-6 h-6 rounded-full flex items-center justify-center text-xs">
                {cartItemCount}
              </span>
            )}
          </button>

          {/* Cart Panel (Desktop) */}
          <div className="hidden lg:block w-96 flex-shrink-0">
            <div className="bg-white rounded-2xl shadow-lg p-6 sticky top-24">
              <div className="flex items-center gap-2 mb-6">
                <ShoppingCart className="w-6 h-6 text-amber-600" />
                <h4 className="text-stone-800">Your Cart ({cartItemCount})</h4>
              </div>

              {cart.length === 0 ? (
                <p className="text-stone-500 text-center py-8">Your cart is empty</p>
              ) : (
                <>
                  <div className="space-y-4 mb-6 max-h-96 overflow-y-auto">
                    {cart.map((item) => (
                      <div key={item.id} className="flex gap-4">
                        <div className="w-20 h-20 flex-shrink-0 rounded-lg overflow-hidden">
                          <ImageWithFallback
                            src={item.image}
                            alt={item.name}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div className="flex-1 min-w-0">
                          <h6 className="text-stone-800 mb-1 truncate">{item.name}</h6>
                          <p className="text-amber-600 mb-2">${item.price}</p>
                          <div className="flex items-center gap-2">
                            <button
                              onClick={() => updateQuantity(item.id, -1)}
                              className="w-7 h-7 rounded-full bg-stone-100 hover:bg-stone-200 flex items-center justify-center"
                            >
                              <Minus className="w-4 h-4" />
                            </button>
                            <span className="w-8 text-center">{item.quantity}</span>
                            <button
                              onClick={() => updateQuantity(item.id, 1)}
                              className="w-7 h-7 rounded-full bg-stone-100 hover:bg-stone-200 flex items-center justify-center"
                            >
                              <Plus className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => removeFromCart(item.id)}
                              className="ml-auto text-red-500 hover:text-red-600"
                            >
                              <X className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="border-t border-stone-200 pt-4 mb-4">
                    <div className="flex justify-between mb-2">
                      <span className="text-stone-600">Subtotal</span>
                      <span className="text-stone-800">${cartTotal.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between mb-2">
                      <span className="text-stone-600">Delivery</span>
                      <span className="text-stone-800">$5.00</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-stone-800">Total</span>
                      <span className="text-amber-600">${(cartTotal + 5).toFixed(2)}</span>
                    </div>
                  </div>

                  <button className="w-full bg-amber-600 hover:bg-amber-700 text-white py-3 rounded-full transition-colors">
                    Proceed to Checkout
                  </button>
                </>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Cart Sidebar (Mobile) */}
      {cartOpen && (
        <>
          <div
            className="lg:hidden fixed inset-0 bg-black/50 z-40"
            onClick={() => setCartOpen(false)}
          />
          <div className="lg:hidden fixed right-0 top-0 bottom-0 w-full max-w-md bg-white z-50 shadow-xl overflow-y-auto">
            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-2">
                  <ShoppingCart className="w-6 h-6 text-amber-600" />
                  <h4 className="text-stone-800">Your Cart ({cartItemCount})</h4>
                </div>
                <button
                  onClick={() => setCartOpen(false)}
                  className="p-2 hover:bg-stone-100 rounded-full"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              {cart.length === 0 ? (
                <p className="text-stone-500 text-center py-8">Your cart is empty</p>
              ) : (
                <>
                  <div className="space-y-4 mb-6">
                    {cart.map((item) => (
                      <div key={item.id} className="flex gap-4">
                        <div className="w-20 h-20 flex-shrink-0 rounded-lg overflow-hidden">
                          <ImageWithFallback
                            src={item.image}
                            alt={item.name}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div className="flex-1 min-w-0">
                          <h6 className="text-stone-800 mb-1 truncate">{item.name}</h6>
                          <p className="text-amber-600 mb-2">${item.price}</p>
                          <div className="flex items-center gap-2">
                            <button
                              onClick={() => updateQuantity(item.id, -1)}
                              className="w-7 h-7 rounded-full bg-stone-100 hover:bg-stone-200 flex items-center justify-center"
                            >
                              <Minus className="w-4 h-4" />
                            </button>
                            <span className="w-8 text-center">{item.quantity}</span>
                            <button
                              onClick={() => updateQuantity(item.id, 1)}
                              className="w-7 h-7 rounded-full bg-stone-100 hover:bg-stone-200 flex items-center justify-center"
                            >
                              <Plus className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => removeFromCart(item.id)}
                              className="ml-auto text-red-500 hover:text-red-600"
                            >
                              <X className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="border-t border-stone-200 pt-4 mb-4">
                    <div className="flex justify-between mb-2">
                      <span className="text-stone-600">Subtotal</span>
                      <span className="text-stone-800">${cartTotal.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between mb-2">
                      <span className="text-stone-600">Delivery</span>
                      <span className="text-stone-800">$5.00</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-stone-800">Total</span>
                      <span className="text-amber-600">${(cartTotal + 5).toFixed(2)}</span>
                    </div>
                  </div>

                  <button className="w-full bg-amber-600 hover:bg-amber-700 text-white py-3 rounded-full transition-colors">
                    Proceed to Checkout
                  </button>
                </>
              )}
            </div>
          </div>
        </>
      )}
    </div>
  );
}