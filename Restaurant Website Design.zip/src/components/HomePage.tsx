import { ImageWithFallback } from './figma/ImageWithFallback';
import { ArrowRight, Star, Clock, Award, Heart } from 'lucide-react';

interface HomePageProps {
  onNavigate: (page: string) => void;
}

export function HomePage({ onNavigate }: HomePageProps) {
  const featuredItems = [
    {
      id: 1,
      name: 'Chicken Biryani',
      description: 'Fragrant basmati rice layered with spiced chicken and saffron',
      price: '$18',
      image: 'https://images.unsplash.com/photo-1589302168068-964664d93dc0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmRpYW4lMjBiaXJ5YW5pJTIwcmljZXxlbnwxfHx8fDE3NjQ0ODAxMDF8MA&ixlib=rb-4.1.0&q=80&w=1080',
    },
    {
      id: 2,
      name: 'Butter Chicken',
      description: 'Tender chicken in rich tomato-butter gravy with aromatic spices',
      price: '$16',
      image: 'https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxidXR0ZXIlMjBjaGlja2VuJTIwY3Vycnl8ZW58MXx8fHwxNzY0NTY3ODgyfDA&ixlib=rb-4.1.0&q=80&w=1080',
    },
    {
      id: 3,
      name: 'Paneer Tikka Masala',
      description: 'Grilled cottage cheese in creamy tomato-cashew sauce',
      price: '$14',
      image: 'https://images.unsplash.com/photo-1567188040759-fb8a883dc6d8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwYW5lZXIlMjB0aWtrYSUyMG1hc2FsYXxlbnwxfHx8fDE3NjQ1NzU2NTF8MA&ixlib=rb-4.1.0&q=80&w=1080',
    },
    {
      id: 4,
      name: 'Gulab Jamun',
      description: 'Soft milk dumplings in warm cardamom-rose syrup',
      price: '$6',
      image: 'https://images.unsplash.com/photo-1666190092159-3171cf0fbb12?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxndWxhYiUyMGphbXVuJTIwZGVzc2VydHxlbnwxfHx8fDE3NjQ0NzU5ODV8MA&ixlib=rb-4.1.0&q=80&w=1080',
    },
  ];

  const reviews = [
    {
      id: 1,
      name: 'Sarah Johnson',
      rating: 5,
      text: 'Absolutely incredible dining experience! The biryani was perfectly spiced and the service was impeccable.',
    },
    {
      id: 2,
      name: 'Michael Chen',
      rating: 5,
      text: 'Best Indian restaurant in town! The butter chicken is heavenly and every dish we tried was authentic.',
    },
    {
      id: 3,
      name: 'Emma Davis',
      rating: 5,
      text: 'From the moment we walked in, we felt welcomed. The flavors are consistently outstanding!',
    },
  ];

  return (
    <div>
      {/* Hero Section */}
      <section className="relative h-[600px] md:h-[700px] overflow-hidden">
        <ImageWithFallback
          src="https://images.unsplash.com/photo-1546833999-b9f581a1996d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmRpYW4lMjB0aGFsaSUyMHBsYXR0ZXJ8ZW58MXx8fHwxNzY0NTc1NjU0fDA&ixlib=rb-4.1.0&q=80&w=1080"
          alt="Signature dish"
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/70 to-black/40" />
        
        <div className="relative h-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center">
          <div className="max-w-2xl text-white">
            <h1 className="mb-6">Experience Authentic Indian Cuisine</h1>
            <p className="text-xl mb-8 text-stone-200">
              Indulge in our signature Indian dishes crafted with passion and the finest authentic spices. Every meal is a celebration of flavor.
            </p>
            <button
              onClick={() => onNavigate('menu')}
              className="bg-amber-600 hover:bg-amber-700 text-white px-8 py-4 rounded-full inline-flex items-center gap-2 transition-all hover:gap-4"
            >
              Order Online
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      </section>

      {/* Featured Menu Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <p className="text-amber-600 mb-2">Our Specialties</p>
            <h2 className="mb-4">Featured Dishes</h2>
            <p className="text-stone-600 max-w-2xl mx-auto">
              Discover our chef's carefully curated selection of signature dishes
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {featuredItems.map((item) => (
              <div
                key={item.id}
                className="group bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1"
              >
                <div className="relative h-64 overflow-hidden">
                  <ImageWithFallback
                    src={item.image}
                    alt={item.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                </div>
                <div className="p-6">
                  <div className="flex justify-between items-start mb-3">
                    <h4 className="text-stone-800">{item.name}</h4>
                    <span className="text-amber-600">{item.price}</span>
                  </div>
                  <p className="text-stone-600 text-sm mb-4">{item.description}</p>
                  <button
                    onClick={() => onNavigate('menu')}
                    className="text-amber-600 hover:text-amber-700 inline-flex items-center gap-1 text-sm transition-all hover:gap-2"
                  >
                    View Details
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>

          <div className="text-center mt-12">
            <button
              onClick={() => onNavigate('menu')}
              className="border-2 border-amber-600 text-amber-600 hover:bg-amber-600 hover:text-white px-8 py-3 rounded-full transition-colors"
            >
              View Full Menu
            </button>
          </div>
        </div>
      </section>

      {/* Reviews Section */}
      <section className="py-20 bg-amber-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <p className="text-amber-600 mb-2">Testimonials</p>
            <h2 className="mb-4">What Our Guests Say</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {reviews.map((review) => (
              <div key={review.id} className="bg-white p-8 rounded-2xl shadow-md">
                <div className="flex gap-1 mb-4">
                  {[...Array(review.rating)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-amber-500 text-amber-500" />
                  ))}
                </div>
                <p className="text-stone-700 mb-6 italic">"{review.text}"</p>
                <p className="text-stone-900">{review.name}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* About Preview Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div className="relative h-[500px] rounded-2xl overflow-hidden">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1759419038843-29749ac4cd2d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyZXN0YXVyYW50JTIwaW50ZXJpb3IlMjBlbGVnYW50fGVufDF8fHx8MTc2NDQ3MTM5MXww&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Restaurant interior"
                className="w-full h-full object-cover"
              />
            </div>

            <div>
              <p className="text-amber-600 mb-2">Our Story</p>
              <h2 className="mb-6">Where Passion Meets Flavor</h2>
              <p className="text-stone-700 mb-6">
                For over 15 years, Savoria has been serving exceptional cuisine in a warm and elegant atmosphere. Our commitment to quality, innovation, and hospitality has made us a beloved dining destination.
              </p>
              <p className="text-stone-700 mb-8">
                Every dish is prepared with locally-sourced ingredients and crafted by our award-winning culinary team, ensuring an unforgettable experience with every visit.
              </p>

              <div className="grid grid-cols-3 gap-6 mb-8">
                <div className="text-center">
                  <div className="w-16 h-16 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-3">
                    <Clock className="w-8 h-8 text-amber-600" />
                  </div>
                  <p className="text-stone-800">15+ Years</p>
                  <p className="text-sm text-stone-600">Experience</p>
                </div>
                <div className="text-center">
                  <div className="w-16 h-16 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-3">
                    <Award className="w-8 h-8 text-amber-600" />
                  </div>
                  <p className="text-stone-800">50+ Awards</p>
                  <p className="text-sm text-stone-600">Recognition</p>
                </div>
                <div className="text-center">
                  <div className="w-16 h-16 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-3">
                    <Heart className="w-8 h-8 text-amber-600" />
                  </div>
                  <p className="text-stone-800">10k+</p>
                  <p className="text-sm text-stone-600">Happy Guests</p>
                </div>
              </div>

              <button
                onClick={() => onNavigate('about')}
                className="border-2 border-amber-600 text-amber-600 hover:bg-amber-600 hover:text-white px-8 py-3 rounded-full transition-colors inline-flex items-center gap-2"
              >
                Learn More About Us
                <ArrowRight className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}